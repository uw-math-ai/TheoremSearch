/-
Copyright (c) 2025 Rémy Degenne. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Rémy Degenne
-/
import Mathlib.Topology.Algebra.MulAction
import Mathlib.Topology.MetricSpace.Bounded

/-! # cadlag functions

-/

open Filter TopologicalSpace Bornology
open scoped Topology

variable {ι E : Type*} [TopologicalSpace ι] [TopologicalSpace E]

/-- The predicate that a function is right continuous. -/
abbrev Function.RightContinuous [PartialOrder ι] (f : ι → E) :=
  ∀ a, ContinuousWithinAt f (Set.Ioi a) a

lemma Function.RightContinuous.continuous_comp {F : Type*} [TopologicalSpace F] [PartialOrder ι]
    {g : E → F}
    {f : ι → E} (hg : Continuous g) (hf : RightContinuous f) : RightContinuous (g ∘ f) :=
  fun x ↦ (hg.tendsto (f x)).comp (hf x)

/-- A function is cadlag if it is right-continuous and has left limits. -/
structure IsCadlag [PartialOrder ι] (f : ι → E) : Prop where
  right_continuous : Function.RightContinuous f
  left_limit : ∀ x, ∃ l, Tendsto f (𝓝[<] x) (𝓝 l)

lemma IsCadlag.add {E : Type*} [Add E] [TopologicalSpace E] [ContinuousAdd E] [PartialOrder ι]
    {f g : ι → E} (hf : IsCadlag f)
    (hg : IsCadlag g) : IsCadlag (f + g) := by
  refine ⟨fun i ↦ ContinuousWithinAt.add (hf.1 i) (hg.1 i), fun i ↦ ?_⟩
  obtain ⟨r, hr⟩ := hf.2 i
  obtain ⟨s, hs⟩ := hg.2 i
  exact ⟨r + s, hr.add hs⟩

lemma IsCadlag.const_smul {E : Type*} [SMul ℝ E] [TopologicalSpace E] [ContinuousSMul ℝ E]
    [PartialOrder ι] {f : ι → E} (hf : IsCadlag f) (r : ℝ) :
    IsCadlag (fun i ↦ r • f i) := by
  refine ⟨fun i ↦ ContinuousWithinAt.const_smul (hf.1 i) r, fun i ↦ ?_⟩
  obtain ⟨l, hl⟩ := hf.2 i
  exact ⟨r • l, hl.const_smul r⟩

/-- A càdlàg function is locally bounded. -/
lemma isLocallyBounded_of_isCadlag {E : Type*} [LinearOrder ι] [PseudoMetricSpace E]
    {f : ι → E} (hf : IsCadlag f) (x : ι) : ∃ t ∈ 𝓝 x, IsBounded (f '' t) := by
  obtain ⟨l, hl⟩ := hf.2 x
  obtain ⟨U, ⟨⟨A, ⟨hp, ⟨W, hW⟩⟩⟩, hU⟩⟩ := Metric.exists_isBounded_image_of_tendsto hl
  obtain ⟨V, ⟨⟨B, ⟨hq, ⟨R, hR⟩⟩⟩, hV⟩⟩ := Metric.exists_isBounded_image_of_tendsto (hf.1 x).tendsto
  refine ⟨A ∩ B, inter_mem hp hq, ?_⟩
  apply IsBounded.subset ((hU.union hV).union (isBounded_singleton : Bornology.IsBounded ({f x})))
  rintro _ ⟨y, ⟨hyL, hyR⟩ , rfl⟩
  rcases lt_trichotomy y x with (hlt | heq | hgt)
  · have : y ∈ U := hW.2 ▸ ⟨hyL, hW.1 hlt⟩
    grind
  · grind
  · have : y ∈ V := hR.2 ▸ ⟨hyR, hR.1 hgt⟩
    grind

open Classical in
private lemma _isBounded_image_of_isLocallyBounded_of_isCompact {X Y : Type*}
    [TopologicalSpace X] [Bornology Y]
    {s : Set X} (hs : IsCompact s) {f : X → Y}
    (hf : ∀ x, ∃ t ∈ 𝓝 x, IsBounded (f '' t)) :
    IsBounded (f '' s) := by
  choose U hU_mem hU_bdd using hf
  obtain ⟨I, -, hI⟩ := hs.elim_nhds_subcover U (fun x _ => hU_mem x)
  apply IsBounded.subset _ (Set.image_mono hI)
  rw [Set.image_iUnion₂]
  refine Finset.induction_on I ?_ ?_
  · simp [isBounded_empty]
  · intro a s _ ih
    simp only [Finset.mem_insert]
    rw [show (⋃ i, ⋃ (_ : i = a ∨ i ∈ s), f '' U i) =
      f '' U a ∪ ⋃ i ∈ s, f '' U i from by
        ext x; simp [Set.mem_iUnion]]
    exact (hU_bdd a).union ih

/-- A càdlàg function maps compact sets to bounded sets. -/
lemma isBounded_image_of_isCadlag_of_isCompact {E : Type*} [LinearOrder ι] [PseudoMetricSpace E]
    {f : ι → E} (hf : IsCadlag f) {s : Set ι} (hs : IsCompact s) :
    IsBounded (f '' s) :=
  _isBounded_image_of_isLocallyBounded_of_isCompact hs (isLocallyBounded_of_isCadlag hf)
